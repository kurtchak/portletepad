package org.webepad.utils;

public class RegExpPatterns {

}
