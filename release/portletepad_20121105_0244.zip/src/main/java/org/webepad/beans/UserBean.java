package org.webepad.beans;

import java.util.List;

import javax.faces.context.FacesContext;
import javax.portlet.PortletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.webepad.dao.UserDAO;
import org.webepad.dao.hibernate.HibernateDAOFactory;
import org.webepad.model.User;

public class UserBean {
	private Logger log = LoggerFactory.getLogger(UserBean.class);

	private User user;
	private UserDAO userDAO = HibernateDAOFactory.getInstance().getUserDAO();
	
	public UserBean() {
//		loadAnotherUser();
//		loadLoggedUser();
	}

//	private void loadAnotherUser() {
//		user = loadUser("karol");
//		System.out.println("USER FOUND: " + user.getName() + " - "+user.getId());
//		loadUser("john");
//	}

//	PORTLET IMPL
	private void loadLoggedUser() {
		FacesContext context = FacesContext.getCurrentInstance();
		PortletRequest req = (PortletRequest) context.getExternalContext().getRequest();
		String name = req.getRemoteUser();
//		log.info("LOGGED USER: " + name);
		if (name == null) {
			user = null;
			return;
		} else if (user != null && name.equals(user.getName())) {
			return;
		} else {
			user = loadUser(name);
			log.info("LOADED USER: " + user.getName());
			if (user == null) {
				user = new User(name);
				save(user);
			}
		}
	}

	public User getUser(Long id) {
		return userDAO.getUser(id);
	}
	
	private void save(User user) {
		userDAO.insert(user);
	}

	private User loadUser(String name) {
		return userDAO.findUser(name);
	}

	public User getUser() {
		return user;
	}
	
	public void setUser(User user) {
		this.user = user;
	}

	/**
	 * RETRIEVE ALL USERS
	 */
	public List<User> getUsers() {
		return userDAO.readUsers();
	}
	
	public User getActualUser() {
		if (user == null) {
			loadLoggedUser();
		}
		return user;
	}
}
