package org.webepad.beans;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.webepad.model.Pad;
import org.webepad.model.Session;
import org.webepad.model.User;

public class APIBean {
	private PadBean padBean;
	private SessionBean sessionBean;
	private UserBean userBean;

	private Logger log = LoggerFactory.getLogger(APIBean.class);

	private String padname;
	
	private String createPadTogglePanelState;

	public APIBean() {
	}

	public List<Pad> getPads() {
		return padBean.getPads();
	}

	public List<Session> getSessions() {
		return sessionBean.getSessions();
	}

	public String createNewPad() {
		User user = userBean.getActualUser();
		Pad pad = padBean.createNewPad(padname, user);
		padBean.loadPad(pad);
		return openPadSession(pad, user);
	}

	public void deletePad() {
		// activePads.remove(pad); // WHAT IF PAD HAS ANOTHER OPENED SESSION
		// WHILE DELETING? - merge handles?
		padBean.deteleSelectedPad();
	}

	public String openListedPad() {
		padBean.loadListedPad();
		Pad pad = padBean.getPad();
		User user = userBean.getActualUser();
		return openPadSession(pad, user);
	}

	public String openPadSession(Pad pad, User user) {
		Session session = padBean.openSession(pad, user);
		sessionBean.loadSession(session);
		if (session != null) {
			return "openPad";
		} else {
			return "error";
		}
	}

	public PadBean getPadBean() {
		return padBean;
	}

	public void setPadBean(PadBean padBean) {
		this.padBean = padBean;
	}

	public UserBean getUserBean() {
		return userBean;
	}

	public void setUserBean(UserBean userBean) {
		this.userBean = userBean;
	}

	public SessionBean getSessionBean() {
		return sessionBean;
	}

	public void setSessionBean(SessionBean sessionBean) {
		this.sessionBean = sessionBean;
	}

	public String getPadname() {
		return padname;
	}

	public void setPadname(String padname) {
		this.padname = padname;
	}

	public String getCreatePadTogglePanelState() {
		return createPadTogglePanelState;
	}

	public void setCreatePadTogglePanelState(String createPadTogglePanelState) {
		this.createPadTogglePanelState = createPadTogglePanelState;
	}

	public void leaveSessionLoggedIn() {
		if (sessionBean != null) {
			sessionBean.leaveSessionLoggedIn();
		}
	}
}
