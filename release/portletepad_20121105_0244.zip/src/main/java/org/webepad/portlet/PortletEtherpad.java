package org.webepad.portlet;

import java.io.IOException;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.PortletRequestDispatcher;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.UnavailableException;
import javax.portlet.faces.GenericFacesPortlet;

import org.webepad.beans.APIBean;
import org.webepad.beans.PadBean;

public class PortletEtherpad extends GenericFacesPortlet {

	private APIBean apiBean;
	private PadBean padBean;
	
	public PortletEtherpad() {
//		apiBean = new APIBean();
//		padBean = new PadBean();
	}
	
	public void doView(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		String userName = (String) request.getRemoteUser();
		String target;
		System.out.println("doView:"+userName);
		if (userName != null) {
			target = "/pages/pads.xhtml";
//			FacesContext context = FacesContext.getCurrentInstance();
//			if (context != null) {
//				ExternalContext extContext = context.getExternalContext();
//				if (extContext != null) {
//					Map<String, Object> sessions = extContext.getSessionMap();
//					apiBean = (APIBean) sessions.get("apiBean");
//					if (apiBean != null) {
//						apiBean.leaveSessionLoggedIn();
//					}
//				}
//			}
		} else {
			target = "/pages/noauth.xhtml";
		}
//		getPortletContext().setAttribute("remoteUser",userName);
		System.out.println("target:"+target);
		super.doView(request, response);
	}

	protected void doHelp(RenderRequest request, RenderResponse response) throws PortletException, IOException,
			UnavailableException {
		response.setContentType("text/html");
		PortletRequestDispatcher prd = getPortletContext().getRequestDispatcher("/pages/help.xhtml");
		prd.include(request, response);
	}

	public void processAction(ActionRequest request, ActionResponse response) throws PortletException, IOException,
			UnavailableException {
//		String userName = (String) request.getParameter(request.getRemoteUser());
//		response.setRenderParameter(request.getRemoteUser(), userName);
//		if (request.getAttribute("padId") != null) {
//			response.setRenderParameter("padId", (String) request.getAttribute("padId"));
//		}
		super.processAction(request, response);
	}

	public APIBean getApiBean() {
		return apiBean;
	}

	public void setApiBean(APIBean apiBean) {
		this.apiBean = apiBean;
	}

	public PadBean getPadBean() {
		return padBean;
	}

	public void setPadBean(PadBean padBean) {
		this.padBean = padBean;
	}
}
